﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace ntoprep
{
    class EmailSender
    {
        private string emailFrom = "ametistik2006@yandex.ru";
        private string emailPassword = "somethingbetter123!";

        public string SendEmail(string subj, string text, string emailTo)
        {
            try
            {
                MailAddress to = new MailAddress(emailTo);
                MailAddress from = new MailAddress(emailFrom);

                MailMessage message = new MailMessage(from, to);
                message.SubjectEncoding = Encoding.UTF8;
                message.BodyEncoding = Encoding.UTF8;
                message.Subject = subj;
                message.Body = text;
                using (SmtpClient mySmtpClient = new SmtpClient())
                {
                    mySmtpClient.UseDefaultCredentials = false;
                    mySmtpClient.EnableSsl = true;
                    mySmtpClient.Credentials = new NetworkCredential(emailFrom, password: emailPassword);
                    mySmtpClient.Host = "smtp.yandex.ru";
                    mySmtpClient.Port = 587;
                    mySmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    mySmtpClient.Send(message);
                }
                return null;
            }
            catch (Exception ex)
            {
                return "Возникла ошибка. Письмо не было отправлено.\nПроверьте корректен ли введённый адрес электронной почты." + ex.ToString();
            }
        }

    }
}
